import matplotlib.pyplot as plt

def plot_accuracies(model_names, accuracies):
    plt.figure(figsize=(10, 6))
    plt.bar(model_names, accuracies, color='skyblue')
    plt.xlabel('Classification Models')
    plt.ylabel('Validation Accuracy (%)')
    plt.title('Validation Accuracy Comparison of Classification Models')
    plt.ylim(0, 100) 
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    model_names = ['Logistic Regression', 'SVM', 'KNN', 'Decision Tree', 'Random Forest', 'CNN']
    accuracies = [91.29, 96.74, 87.50, 82.40, 95.36, 98.70]  

    plot_accuracies(model_names, accuracies)
