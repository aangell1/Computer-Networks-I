import itertools
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split, GridSearchCV
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.optimizers import Adam, SGD


def load_and_preprocess_data_cnn(train_file='training.csv'):

    train_data = pd.read_csv(train_file)
    X = train_data.iloc[:, 1:].values.reshape(-1, 28, 28, 1) / 255.0  
    y = train_data.iloc[:, 0].values  #
    y = to_categorical(y, num_classes=10)

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    return X_train, X_val, y_train, y_val

# Define CNN model
def create_cnn_model(optimizer, filters, kernel_size, activation):
    model = Sequential()

    # Convolutional Layer 1
    model.add(Conv2D(filters=filters, kernel_size=(kernel_size, kernel_size), activation=activation, input_shape=(28, 28, 1)))
    model.add(MaxPooling2D(pool_size=(2, 2)))

    # Convolutional Layer 2
    model.add(Conv2D(filters=filters * 2, kernel_size=(kernel_size, kernel_size), activation=activation))
    model.add(MaxPooling2D(pool_size=(2, 2)))

    # Flatten before fully connected layers
    model.add(Flatten())

    # Fully connected layers
    model.add(Dense(128, activation=activation))
    model.add(Dropout(0.5)) 

    model.add(Dense(10, activation='softmax'))

    model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])

    return model
def manual_grid_search(X_train, y_train, X_val, y_val):
    batch_sizes = [32, 64]
    epochs_list = [5, 10]
    optimizers = ['adam', 'sgd']
    filters_list = [32, 64]
    kernel_sizes = [3, 5]
    activations = ['relu', 'tanh']

    
    best_acc = 0.0
    best_params = None

    
    for batch_size, epochs, optimizer, filters, kernel_size, activation in itertools.product(batch_sizes, epochs_list, optimizers, filters_list, kernel_sizes, activations):
        print(f"Training with batch_size={batch_size}, epochs={epochs}, optimizer={optimizer}, filters={filters}, kernel_size={kernel_size}, activation={activation}")
       
        
        model = create_cnn_model(optimizer=optimizer, filters=filters, kernel_size=kernel_size, activation=activation)
        model.fit(X_train, y_train, batch_size=batch_size, epochs=epochs, verbose=0)

        
        val_loss, val_acc = model.evaluate(X_val, y_val, verbose=0)

        if val_acc > best_acc:
            best_acc = val_acc
            best_params = {
                'batch_size': batch_size,
                'epochs': epochs,
                'optimizer': optimizer,
                'filters': filters,
                'kernel_size': kernel_size,
                'activation': activation
            }

        print(f"Validation accuracy: {val_acc:.4f} for params {best_params}")

    return best_params, best_acc


def main():
    X_train, X_val, y_train, y_val = load_and_preprocess_data_cnn('training.csv')
   
    best_params, best_acc = manual_grid_search(X_train, y_train, X_val, y_val)
   
    print(f"Best Hyperparameters: {best_params}")
    print(f"Best CNN Model Accuracy on Validation Set: {best_acc:.4f}")

if __name__ == "__main__":
    main()