from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score
from data_preprocessing import preprocess_data

def train_logistic_regression(X_train, y_train):
    param_grid = {
        'C': [0.1, 1, 10],
        'solver': ['liblinear', 'lbfgs']
    }
    model = LogisticRegression(max_iter=1000)
    grid_search = GridSearchCV(model, param_grid, cv=5, scoring='accuracy')

    grid_search.fit(X_train, y_train)

    print(f"Best Parameters: {grid_search.best_params_}")
    return grid_search.best_estimator_

def evaluate_logistic_regression(model, X_val, y_val):
    y_pred = model.predict(X_val)
    accuracy = accuracy_score(y_val, y_pred)
    print(f"Logistic Regression Validation Accuracy: {accuracy * 100:.2f}%")
    return accuracy 

if __name__ == "__main__":
    X_train, X_val, y_train, y_val, _ = preprocess_data('training.csv', 'testing.csv')
    model = train_logistic_regression(X_train, y_train)
    accuracy = evaluate_logistic_regression(model, X_val, y_val)
