# Digit Classification using Machine Learning

This project implements six machine learning algorithms to classify hand drawn digits based on their pixel values. The dataset consists of images of hand drawn digits, where each image is represented by a 28x28 pixel grid.

## Project Structure

The project contains the following files:

- **`data_preprocessing.py`**: Handles data loading and preprocessing. It reads the training and testing datasets, normalizes the pixel values, and splits the training data into training and validation sets.
- **`logistic_regression.py`**: Trains and evaluates a Logistic Regression model using grid search for hyperparameter tuning.
- **`svm.py`**: Trains and evaluates a Support Vector Machine model using grid search for hyperparameter tuning.
- **`knn.py`**: Trains and evaluates a K-Nearest Neighbors model using grid search for hyperparameter tuning.
- **`decision_tree.py`**: Trains and evaluates a Decision Tree classifier using grid search for hyperparameter tuning.
- **`random_forest.py`**: Trains and evaluates a Random Forest classifier using grid search for hyperparameter tuning.
- **`ann.py`**: Trains and evaluates an Convulutional Neural Network using TensorFlow/Keras.
- **`plot_results.py`**: Plots a comparison of the validation accuracy across all models.

## Requirements

To run this project, you need Python 3 and the following Python libraries:

- `pandas`
- `scikit-learn`
- `tensorflow` 
- `matplotlib`
 
You can install the dependencies using `pip`:

```bash
pip install pandas scikit-learn tensorflow matplotlib
