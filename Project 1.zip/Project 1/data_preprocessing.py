import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

def preprocess_data(train_path, test_path):
    train_data = pd.read_csv(train_path)
    test_data = pd.read_csv(test_path)

    X = train_data.drop('label', axis=1)

    scaler = StandardScaler()
    X = X / 255.0
    test_data = test_data / 255.0

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    return X_train, X_val, y_train, y_val, test_data

if __name__ == "__main__":
    X_train, X_val, y_train, y_val, test_data = preprocess_data('training.csv', 'testing.csv')
    print("Data preprocessing completed.")
