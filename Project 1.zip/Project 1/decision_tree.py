from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score
from data_preprocessing import preprocess_data

def train_decision_tree(X_train, y_train):
    param_grid = {
        'max_depth': [5, 10, 20],
        'min_samples_split': [2, 5, 10]
    }

    model = DecisionTreeClassifier()
    grid_search = GridSearchCV(model, param_grid, cv=5, scoring='accuracy')

    
    grid_search.fit(X_train, y_train)

    print(f"Best Parameters: {grid_search.best_params_}")
    return grid_search.best_estimator_

def evaluate_decision_tree(model, X_val, y_val):
    y_pred = model.predict(X_val)
    accuracy = accuracy_score(y_val, y_pred)
    print(f"Decision Tree Validation Accuracy: {accuracy * 100:.2f}%")
    return accuracy  

if __name__ == "__main__":
    X_train, X_val, y_train, y_val, _ = preprocess_data('training.csv', 'testing.csv')
    model = train_decision_tree(X_train, y_train)
    accuracy = evaluate_decision_tree(model, X_val, y_val)

