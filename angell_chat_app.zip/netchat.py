import socket
import sys
import threading
import random
import struct
import select
from inputimeout import inputimeout, TimeoutOccurred
import signal


lock = threading.Lock()
terminate_flag = False  # Flag to terminate threads

# Start chat session
def start_chat_session(port):
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        udp_socket.bind(("", port))
        print(f"Chat session started. Listening on port {port}...")
    except Exception as e:
        print(f"Failed to bind to port {port}: {e}")
        sys.exit(1)
    return udp_socket

def send_messages(udp_socket, peer_ip, peer_port):
    while True:
        with lock:
            # Prompt user for message or peer IP to initiate a session
            message = input_with_timeout("Enter message to send (or type 'quit' to exit): ")
        
        if message is None:  # If timeout occurs
            continue

        if message.lower() == 'quit':
            with lock:
                print("Exiting the chat...")
            udp_socket.close()
            sys.exit(0)

        # Check if  sending a session request or a normal message
        if message.lower() == "request session":
            # Send session request
            message_type = 2  # 2 for session request
            random_number = random.randint(0, 2**32 - 1)  # Generate a 4-byte random number
            
            # Create the header (1-byte type + 4-byte random number)
            header = struct.pack('!B I', message_type, random_number)
            full_message = header + b"SESSION REQUEST"

            udp_socket.sendto(full_message, (peer_ip, peer_port))
            print(f"Sent session request to {peer_ip}:{peer_port} with random number {random_number}")
        else:
            # Sending a normal message
            message_type = 1  # 1 for normal message
            random_number = random.randint(0, 2**32 - 1)

            # Create the header (1-byte type + 4-byte random number) and append the message
            header = struct.pack('!B I', message_type, random_number)
            full_message = header + message.encode()

            udp_socket.sendto(full_message, (peer_ip, peer_port))
            print(f"Sent message to {peer_ip}:{peer_port} with random number {random_number}")


def receive_messages(udp_socket):
    udp_socket.settimeout(5)  # Set timeout to 5 seconds
    retries = 0
    max_retries = 3

    while True:
        try:
            data, addr = udp_socket.recvfrom(1024)

            # Unpack the header (1-byte message type, 4-byte random number)
            message_type, random_number = struct.unpack('!B I', data[:5])
            message = data[5:].decode()  # The actual message starts after the 5-byte header

            # Handle the message types
            if message_type == 2:  # Session request
                with lock:
                    print(f"#session request from: {addr[0]}:{addr[1]}")
                    response = input(f"[{addr[0]}:{addr[1]}] accept request? (y/n) ")
                    if response.lower() == 'y':
                        # Send confirmation of accepted session
                        confirmation = struct.pack('!B I', 3, random_number)  # 3 = session confirmation
                        udp_socket.sendto(confirmation, addr)
                        print(f"#success: {addr[0]}:{addr[1]}")
                    else:
                        # Send failure message
                        failure_msg = struct.pack('!B I', 4, random_number)  # 4 = session rejection
                        udp_socket.sendto(failure_msg, addr)
                        print(f"#failure: {addr[0]}:{addr[1]}")
            
            elif message_type == 3:  # Session confirmation
                with lock:
                    print(f"Session confirmed with {addr[0]}:{addr[1]} (Random #: {random_number})")

            elif message_type == 4:  # Session rejection
                with lock:
                    print(f"Session request rejected by {addr[0]}:{addr[1]} (Random #: {random_number})")
                    # You can handle disconnection here if needed
            
            elif message_type == 1:  # Regular message
                with lock:
                    print(f"Received message from {addr}: {message} (Type: {message_type}, Random #: {random_number})")

            elif message_type == 5:  # Session termination
                with lock:
                    print(f"Session with {addr[0]}:{addr[1]} terminated (Random #: {random_number})")
                    udp_socket.close()
                    sys.exit(0)

            retries = 0  # Reset retries upon successful message receipt

        except socket.timeout:
            retries += 1
            if retries > max_retries:
                with lock:
                    print(f"No response after {max_retries} retries. Terminating session.")
                udp_socket.close()
                sys.exit(0)  # Exit the program
            else:
                with lock:
                    print(f"No response within 5 seconds. Retrying... ({retries}/{max_retries})")

        except KeyboardInterrupt:
            with lock:
                print("\nChat session ended.")
            udp_socket.close()
            sys.exit(0)


def terminate_session(signal, frame):
    with lock:
        print("\nTerminating session...")
        termination_msg = struct.pack('!B I', 5, 0)  # 5 = session termination
        udp_socket.sendto(termination_msg, (peer_ip, peer_port))
    sys.exit(0)

# Bind the SIGQUIT signal to the termination handler
signal.signal(signal.SIGQUIT, terminate_session)



def input_with_timeout(prompt, timeout=5):
    try:
        # Try to get input within the specified timeout
        return inputimeout(prompt, timeout)
    except TimeoutOccurred:
        print("\nTimeout occurred! Returning to #chat with?")
        return None



# Main function
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python netchat.py <port>")
        sys.exit(1)

    port = int(sys.argv[1])
    udp_socket = start_chat_session(port)

    # Get peer information from user
    peer_ip = input("Enter peer IP: ")
    peer_port = int(input("Enter peer port: "))
    
    # Create threads for sending and receiving messages
    send_thread = threading.Thread(target=send_messages, args=(udp_socket, peer_ip, peer_port))
    receive_thread = threading.Thread(target=receive_messages, args=(udp_socket,))

    # Start both threads
    send_thread.start()
    receive_thread.start()

    # Wait for both threads to finish
    send_thread.join()
    receive_thread.join()

    print("Session ended.")
