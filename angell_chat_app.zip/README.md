Chat Application README
1. Project Overview
This project is a simple P2P  chat application built using Python's socket library. It allows two users to send and receive messages via UDP, but mimics TCP. The application supports session requests, regular message exchanges, and session termination.

2. Features
Send and receive messages between two peers.
Session requests that require user acceptance before message exchange.
Timeout and retry mechanism for lost messages.
Graceful session termination with Ctrl-\.
3. Requirements
Python 3.10 or higher.
The following Python libraries are required:
socket
threading
struct
sys
select
random
inputimeout
4. How to Set Up the Application
Clone or Download the Repository: Download or clone the repository containing the netchat.py script and the README file.  Make sure to use this on a Linux Enviornment, like a FABRIC virtual machine.

Install the Libraris:


pip install inputimeout
Run the Application on Two Machines: You will need two machines or terminal windows to run the script. Do the following steps:

On Machine/Node 1:

Start the application with:
python3 netchat.py 5555
Enter the IP address of the second machine and port 6666.
To find the IP address on the current machine, use the command: sudo netstat -uln
On Machine/Node 2:

Start the application with:
python3 netchat.py 6666
Enter the IP address of the first machine and port 5555.
How to Use the Application

Once the application is running, follow the prompts to send messages between the two peers.
Message Exchange: Once the session is established, you can send and receive messages.
Session Termination: Enter 'quit' , Ctrl + C , or  Ctrl + \ to terminate the session. This will close the connection and stop the program.
5. Known Issues
If you encounter a Bad file descriptor error, it is likely due to terminating a session without properly closing the receive thread. Make sure to handle graceful session termination using the correct controls.
